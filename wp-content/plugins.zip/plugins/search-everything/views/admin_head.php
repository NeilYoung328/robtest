<script type="text/javascript">
	var externalSearchEnabled = <?php echo $se_metabox["external_search_enabled"] ? "true" : "false"; ?>;
</script>
