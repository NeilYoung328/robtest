<?php


echo "this is live magid";


 ?>